#!/usr/bin/ruby1.8
#

require "/usr/share/liboml2-dev/oml4r.rb"
require 'pty'

APPNAME = "iriswrap"
APPPATH = "/usr/local/bin/irisv2"
APPVERSION = "1.0"

class Database

  def self.insert_db(hostname,timestamp,usrpid,ch11,ch12,ch13,ch14,ch15,ch16,ch17,ch18,ch19,ch20,ch21,ch22,ch23,ch24,ch25,ch26)
    cmd = "mysql -h10.11.31.22 -ulwei -plwei lwei -e \"insert into zigbee (hostname,timestamp,usrpid,ch11,ch12,ch13,ch14,ch15,ch16,ch17,ch18,ch19,ch20,ch21,ch22,ch23,ch24,ch25,ch26) values(\'#{hostname}\',#{timestamp},#{usrpid},#{ch11},#{ch12},#{ch13},#{ch14},#{ch15},#{ch16},#{ch17},#{ch18},#{ch19},#{ch20},#{ch21},#{ch22},#{ch23},#{ch24},#{ch25},#{ch26});\""
    puts cmd
    value = %x[ #{cmd} ]

  end

  def self.querry_psd(usrpid,timeold)
	cmd = "mysql -h10.11.31.22 -ulwei -plwei lwei -e \'select * from zigbee where usrpid=#{usrpid} and timestamp>#{timeold} limit 1 ;\'"
	value = %x[ #{cmd} ]
        column=value.split("\n")
        column=column[1].split(" ")
        return column
  end

end
class MPStat < OML4R::MPBase
    name :iriswrapmp
    param :hostname
    param :timestamp_us, :type => :string # timestamp of the received PSD us 
    param :usrpid, :type => :string # usrp id
    param :psd11, :type => :long # PSD value 
    param :psd12, :type => :long # PSD value
    param :psd13, :type => :long # PSD value
    param :psd14, :type => :long # PSD value
    param :psd15, :type => :long # PSD value
    param :psd16, :type => :long # PSD value
    param :psd17, :type => :long # PSD value
    param :psd18, :type => :long # PSD value
    param :psd19, :type => :long # PSD value
    param :psd20, :type => :long # PSD value
    param :psd21, :type => :long # PSD value
    param :psd22, :type => :long # PSD value
    param :psd23, :type => :long # PSD value
    param :psd24, :type => :long # PSD value
    param :psd25, :type => :long # PSD value
    param :psd26, :type => :long # PSD value
end

class Wrapper
  def process_output(output)
      cmd = "/bin/hostname"
      $node = `#{cmd}`
      $node = $node.delete("\n").strip
      column = output.split(",")
      if column.size() == 18
      	#time_ms = (column[0].to_f / 100000.0).to_i
      	Database.insert_db("#{$node}",column[0],column[1],column[2],column[3],column[4],column[5],column[6],column[7],column[8],column[9],column[10],column[11],column[12],column[13],column[14],column[15],column[16],column[17])
        MPStat.inject("#{$node}",column[0],column[1],column[2],column[3],column[4],column[5],column[6],column[7],column[8],column[9],column[10],column[11],column[12],column[13],column[14],column[15],column[16],column[17]) # use both databases
      	puts "inject db usrpid #{column[1]}, psd #{column[2]},psd #{column[3]} "
      end
  end

  def initialize(args)
    # Initialise some variable specific to this wrapper
    @xmlfile = nil

    # Now call the Init of OML4R with the command line arguments (args)
    # and a block defining the arguments specific to this wrapper
    OML4R::init(args, { :appID => APPNAME, :omlServer => '10.11.31.25', })  { |argParser|
        argParser.on("-f xmlfile", "--xmlfile file", "xmlfile for configuration") { |name| 
    		@xmlfile = name 
	}

    }

    # Finally do some checking specific to this wrapper
    # e.g. here we do not proceed if the user did not give us a 
    # valid interface to monitor
    unless @xmlfile != nil
      raise "You did not specify a radio to run!"
    end
  end
    
  def start()
    cmd = ""

    cmd = "#{APPPATH} -f /omf_root/config.ini #{@xmlfile}"
## Works, but always delay the output till the end of the experiment
#    output = IO.popen(cmd)
#      
#    output.each {|line| 
#	print "processing output" + line
#        process_output(line)
#    }

## Works
     PTY.spawn cmd do |r,w,p|
        loop { puts r.gets
               process_output(r.gets) }
     end
  end
end
begin
  app = Wrapper.new(ARGV)
  app.start()
rescue Exception => ex
  puts "Received an Exception when executing the Iris wrapper!"
  puts "The Exception is: #{ex}\n"
end
