#!/bin/bash
cd /home/usrpuser/Documents/iris_se_2012_6_26/
/usr/local/bin/irisv2 $1 config.ini $2 2>&1
## run like ./setuppipe.sh pipe name 60005  (60005 is the port number)

