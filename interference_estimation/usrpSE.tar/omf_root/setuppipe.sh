#!/bin/bash
cd /home/usrpuser/Documents/Slovenia_test/power_over_chan_omf
rm $2
mkfifo $2
chmod 666 $2
while true; do
echo database connection setup
cat $2 | nc 10.11.31.22 $3
#cat $2 | nc wilabfs.atl $3
done
## run like ./setuppipe.sh pipe name 60005  (60005 is the port number)

