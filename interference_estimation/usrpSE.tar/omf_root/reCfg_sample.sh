#!/bin/bash

# findreplace function
# $1 is the xml file name to be modified
# $2 is the target parameter
# $3 is the new value for the target parameter

findreplace()
{
	TEMP=$(grep $2 $1 | awk -F \" '{ print $4 }')
	OLD_PARAM=$(echo $TEMP | awk '{ print $1 }') # when the same field appear multiple times, select the first value
#	echo $TEMP
#	echo $OLD_PARAM
	REPLACE_CMD="s/$2\" value=\"$OLD_PARAM\"/$2\" value=\"$3\"/g"
#	echo $REPLACE_CMD
	perl -pi -e "$REPLACE_CMD" $1
}
# run as ./reCfg_sample.sh inputSize outputSize xmlfile
# inputSize is the size from FFT/ Periodogram componennt
# outputSize is the size from sample selector, edge removed
xmlfile=$3
inputBlocksize=$1
outputBlocksize=$2
offsetsize=$(echo $1/2-$2/2 | bc)
echo $offsetsize
findreplace $xmlfile blocksize $1
findreplace $xmlfile sampleoffset $offsetsize
findreplace $xmlfile sampletotal $2
findreplace $xmlfile numofbin $2
