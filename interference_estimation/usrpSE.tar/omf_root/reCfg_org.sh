#!/bin/bash

# findreplace function
# $1 is the xml file name to be modified
# $2 is the target parameter
# $3 is the new value for the target parameter
findreplace()
{
	TEMP=$(grep $2 $1 | awk -F \" '{ print $4 }')
	OLD_PARAM=$(echo $TEMP | awk '{ print $1 }') # when the same field appear multiple times, select the first value
	echo $TEMP
	echo $OLD_PARAM
	REPLACE_CMD="s/$2\" value=\"$OLD_PARAM\"/$2\" value=\"$3\"/g"
	echo $REPLACE_CMD
	perl -pi -e "$REPLACE_CMD" $1
}
# run as ./reCfg -a xmlfile channel gain nsamps
xmlfile=$2
channel=$3
gain=$4
nsamps=$5
# change channel in 2.4GHz for WIFI standard
WIFIchannel=(dummy 2412000000 2417000000 2422000000 2427000000 2432000000 2437000000 2442000000 2447000000 2452000000 2457000000 2462000000 2467000000 2472000000 2484000000)
# define start and end frequency in the USRPRxComponent
findreplace $xmlfile startfrequency ${WIFIchannel[$channel]}
findreplace $xmlfile endfrequency ${WIFIchannel[$channel]}
# define the channel center frequency in the power integration component
findreplace $xmlfile firstchannel ${WIFIchannel[$channel]}
findreplace $xmlfile freq_start $(echo ${WIFIchannel[$channel]}-10000000 | bc)
findreplace $xmlfile freq_end $(echo ${WIFIchannel[$channel]}+10000000 | bc)

# change gain
findreplace $xmlfile gain $gain

# change the number of samples for processing
findreplace $xmlfile outputblocksize $nsamps
findreplace $xmlfile number_of_complex_samples $nsamps
