#!/bin/bash

#Run this script with the interface as the first parameter. For example with interface eth0, run "./setupusrp2 -i eth0 networkaddress"

#Bring up the interface and set IP
sudo ifconfig $2 up
sudo ifconfig $2 10.11.20.$3 netmask 255.255.255.252 
echo Interface up

#Add a route to direct all usrp traffic to the correct interface
#sudo route add -net 192.168.$2.0 netmask 255.255.255.0 gw 192.168.$2.1 dev $1
#echo Route added

#Turn on flow control on the interface
sudo ethtool -A $2 rx on 2>&1
echo Flow control on

sudo sysctl -w net.core.rmem_max=50000000
echo rmem max





