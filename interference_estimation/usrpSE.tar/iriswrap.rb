#!/usr/bin/ruby1.8
#

require "/usr/share/liboml2-dev/oml4r.rb"

APPNAME = "iriswrap"
APPPATH = "/usr/local/bin/irisv2"
APPVERSION = "1.0"

class MPStat < OML4R::MPBase
    name :iriswrapmp
    param :hostname
    param :timestamp_us, :type => :string # timestamp of the received PSD us 
    param :usrpid, :type => :string # usrp id
    param :psd, :type => :long # PSD value 
end

class Wrapper
  def process_output(output)
      cmd = "/bin/hostname"
      $node = `#{cmd}`
      $node = $node.delete("\n").strip
      column = output.split(",")
      if column.size() == 3
      	#time_ms = (column[0].to_f / 100000.0).to_i
      	MPStat.inject("#{$node}",column[0],column[1],column[2])
      	puts "inject db usrpid #{column[1]}, psd #{column[2]}"
      end
  end

  def initialize(args)
    # Initialise some variable specific to this wrapper
    @xmlfile = nil

    # Now call the Init of OML4R with the command line arguments (args)
    # and a block defining the arguments specific to this wrapper
    OML4R::init(args, { :appID => APPNAME, :omlServer => '10.11.31.25', })  { |argParser|
        argParser.on("-f xmlfile", "--xmlfile file", "xmlfile for configuration") { |name| 
    		@xmlfile = name 
	}

    }

    # Finally do some checking specific to this wrapper
    # e.g. here we do not proceed if the user did not give us a 
    # valid interface to monitor
    unless @xmlfile != nil
      raise "You did not specify a radio to run!"
    end
  end
    
  def start()
    cmd = ""

    cmd = "#{APPPATH} -f /omf_root/config.ini #{@xmlfile}"
    output = IO.popen(cmd)
      
    output.each {|line| 
	print "processing output" + line
        process_output(line)
    }
  end
end
begin
  app = Wrapper.new(ARGV)
  app.start()
rescue Exception => ex
  puts "Received an Exception when executing the Iris wrapper!"
  puts "The Exception is: #{ex}\n"
end
